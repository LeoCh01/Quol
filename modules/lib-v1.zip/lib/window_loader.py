import logging
import os
import sys
import importlib

from PySide6.QtCore import Signal

from lib.global_input_manager import GlobalInputManager
from lib.io_helpers import read_json, write_json


class ToolLoader:
    def __init__(self, name, tools_dir):
        self.name = name
        self.module = None
        self.path = os.path.abspath(os.getcwd() + f'\\{tools_dir}\\{name}')

    def load(self):
        module_path = os.path.join(self.path, 'window.py')

        if os.path.exists(module_path):
            if self.path not in sys.path:
                sys.path.insert(0, self.path)

            # load lib
            lib_path = os.path.join(self.path, 'lib')
            if os.path.isdir(lib_path) and lib_path not in sys.path:
                sys.path.insert(0, lib_path)

            spec = importlib.util.spec_from_file_location(self.name, module_path)
            self.module = importlib.util.module_from_spec(spec)
            sys.modules[self.name] = self.module
            spec.loader.exec_module(self.module)
        else:
            logging.error(f'Script {self.name} does not exist at {module_path}.')
            return False

        return True

    def create_window(self, context, app=None):
        return self.module.MainWindow(WindowInfo(self.path), context)


class SystemToolLoader(ToolLoader):
    def __init__(self):
        super().__init__('quol', '')
        self.path = f'{os.getcwd()}\\quol'

    def create_window(self, context, app=None):
        return self.module.MainWindow(app, WindowInfo(self.path), context)


class WindowInfo:
    def __init__(self, path):
        self.path = path
        self.config_path = path + '\\res\\config.json'

    def save_config(self, config):
        write_json(self.config_path, config)

    def load_config(self):
        return read_json(self.config_path)


class WindowContext:
    def __init__(self, toggle: Signal(bool, bool), toggle_tools, toggle_tools_instant, settings, transition_plugin, get_is_hidden, input_manager):
        self.toggle = toggle
        self.toggle_windows = toggle_tools
        self.toggle_windows_instant = toggle_tools_instant
        self.transition_plugin = transition_plugin
        self.settings = settings
        self.get_is_hidden = get_is_hidden
        self.input_manager: GlobalInputManager = input_manager
